let data = [
   {
      id : 1,
      title : "삼색나물 단호박솥밥",
      content : "담백하고 고소한 별미 도시락",
      price : 39200,
      main : "3namul.jpg",
      detail : "3namul-info.jpg"
   },
   {
      id : 2,
      title : "다섯가지 야채 새우 볶음밥",
      content : "새우, 닭가슴살, 야채 듬뿍",
      price : 35400,
      main : "5vege.jpg",
      detail : "5vege-info.jpg"
   },
   {
      id : 3,
      title : "코코넛 닭가슴살 커리",
      content : "코코넛 커리로 특별하게",
      price : 39200,
      main : "coconut.jpg",
      detail : "coconut-info.jpg"
   },
   {
      id : 4,
      title : "통단호박 크랜베리 콕콕 샐러드",
      content : "단호박 고유의 맛을 그대로",
      price : 22200,
      main : "cranberry.jpg",
      detail : "cranberry-info.jpg"
   },
   {
      id : 5,
      title : "갈비맛 빅볼 닭가슴살",
      content : "균형잡힌 구성으로 제대로 된 한끼!",
      price : 35400,
      main : "galbi.jpg",
      detail : "galbi-info.jpg"
   },
   {
      id : 6,
      title : "갈릭 케이준 치킨 샐러드",
      content : "with 홀그레인 머스타드 드레싱",
      price : 32400,
      main : "garlic.jpg",
      detail : "garlic-info.jpg"
   },

];

export default data;