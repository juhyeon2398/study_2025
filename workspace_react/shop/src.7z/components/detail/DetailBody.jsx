import React from 'react';

const DetailBody = () => {
   return (
      <div>
         
      </div>
   );
};

export default DetailBody;