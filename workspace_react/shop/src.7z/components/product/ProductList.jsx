import React from 'react';
import styled from 'styled-components';
import Product from './Product';

const ProductGrid = styled.div`
  max-width: 70%;
  margin-right: auto;
  margin-left: auto;
  display: grid;
  gap:10px 20px;
  grid-template-rows: 1fr;
  grid-template-columns: 1fr 1fr 1fr;
`;

const ProductList = ({data}) => {
   return (
      <ProductGrid>
         {
            data.map((item,idx) => {
               return <Product key={item.id} data={item}/>
            })
         }
      </ProductGrid>
   );
};

export default ProductList;