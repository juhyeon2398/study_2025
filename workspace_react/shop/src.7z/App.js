import Display from './display/Display';

function App() {
  return (
    <div className="App">
      <Display/>
    </div>
  );
}

export default App;
